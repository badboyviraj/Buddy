<?php 
$n=$_POST['fname'];
$l=$_POST['lname'];


?>
<!DOCTYPE html>
<html>
<head>
	<title>ThankYou</title>
	<style type="text/css">
		body{background-image: linear-gradient(90deg, #008793,pink);
			background:cover}
		#complete {color:red; font-size:50px;margin-top:0px;
					text-align:center;;font-family:britannic;
				 
}
		#reg {color:#f4d742; font-size:35px;margin-top:0px;background-color:transparent;
				text-align:center;}
		#num {color:blue; font-size:35px;margin-top:0px;background-color:transparent;
				text-align:center; font-weight:bolder;}
		h3 {color:#41f492; font-size:35px;margin-top:0px;background-color:transparent;
				text-align:center;}
	</style>
</head>
<body>
	<div id="complete"><h1>Thankyou for Register</h1></div>
<div id="reg"><h2>
	<?php echo $n; ?>
	<?php 
	if(isset($_REQUEST['mname'])){
	echo($_REQUEST['mname']);
	} ?>
	
	<?php echo $l; ?><span>&nbsp;</span>
	
</h2>

</div>
<div id="regno">
	<h3>Your Registration No is :- <span id="num"></span> </h3>
	
</div>
	<script type="text/javascript">
		var x=Math.floor((Math.random()*10000)+1);

		document.getElementById('num').innerHTML="DCFIC00"+x;
	</script></div>
	
	

</body>
</html>
